document.querySelectorAll('[data-confirm]').forEach((el) => {
  el.addEventListener('click', (event) => {
    if (!confirm(el.getAttribute('data-confirm') || 'Are you sure?')) event.preventDefault();
  });
});
