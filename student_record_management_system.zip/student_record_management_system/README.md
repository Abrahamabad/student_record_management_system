# Student Record Management System

A beginner-friendly PHP + MySQL CRUD application for a school hosting assignment.

## Features
- Administrator login/logout with hashed passwords
- Dashboard and student statistics
- Add, list, search, edit, and delete student records
- PDO prepared statements, output escaping, CSRF tokens, and session ID regeneration
- Responsive layout

## Requirements
- XAMPP with Apache, PHP, and MySQL/MariaDB
- Web browser and code editor
- InfinityFree PHP + MySQL hosting account for deployment

## A. Run locally with XAMPP
1. Install and open XAMPP Control Panel.
2. Start **Apache** and **MySQL**.
3. Copy the `student_record_management_system` folder into `C:\xampp\htdocs\`.
4. Open `http://localhost/phpmyadmin`.
5. Click **New**, create a database named `student_records`, and choose `utf8mb4` if asked.
6. Open `http://localhost/student_record_management_system/setup.php`.
7. Create your administrator username and password.
8. Sign in at `http://localhost/student_record_management_system/login.php`.
9. Add, edit, search, and delete sample student records.
10. Before putting real data online, use only data you are authorized to handle. For a classroom demo, use fictional sample records.

## B. Deploy to InfinityFree
1. Create and verify an account at https://www.infinityfree.com/.
2. In the client area, create a hosting account and choose an available free subdomain.
3. Open the hosting account's Control Panel.
4. Open **MySQL Databases** and create a database.
5. Copy the exact database hostname, database name, username, and password. The database hostname is usually not `localhost`.
6. Open the database's phpMyAdmin from the hosting control panel.
7. In local XAMPP phpMyAdmin, select `student_records` > **Export** > Quick > SQL > **Go**. Save the `.sql` file.
8. In hosting phpMyAdmin, select the newly created hosting database > **Import** > choose the exported SQL file > **Go**.
9. Open the local project's `config.php` in your editor. Replace the four database constants with the exact hosting values:
   - `DB_HOST`: hosting MySQL hostname
   - `DB_NAME`: full database name shown by the host
   - `DB_USER`: database username shown by the host
   - `DB_PASS`: database password
   Do not use the local XAMPP values on the live website. Do not share the password or publish it.
10. Upload the project files and folders (`index.php`, `login.php`, `dashboard.php`, `students.php`, `student_form.php`, `delete_student.php`, `logout.php`, `config.php`, `includes/`, `assets/`, and `.htaccess`) into the hosting account's `htdocs` folder. Use the hosting File Manager or FTP details with an FTP client.
11. Do **not** upload the `database` folder or README unless needed. The database has already been imported.
12. Visit `https://YOUR-SUBDOMAIN/setup.php` once. Since the imported SQL creates the tables, the setup page should let you create the first admin if no admin exists. If the admin already exists from a previous export, it will tell you so.
13. Immediately delete `setup.php` from `htdocs` after setup. This is important.
14. Visit `https://YOUR-SUBDOMAIN/` and sign in.
15. Test adding, searching, editing, and deleting a fictional student record.
16. Enable/confirm HTTPS in your hosting control panel and use the HTTPS address.

### Important hosting notes
- InfinityFree's MySQL server hostname is shown in its control panel. Do not assume it is `localhost`.
- Free-hosting MySQL is accessed by PHP scripts on the hosting account and the provider's phpMyAdmin, not by connecting your local desktop database client directly.
- Keep `config.php` private. Never post database credentials in screenshots or chat.
- Remove `setup.php` after initial installation.
- Back up/export the database before making major changes.
- Free-hosting limits and control-panel labels can change; follow the current values shown in your account.

## Troubleshooting
- **Database connection error:** verify host, database name, username, and password exactly; confirm database was created.
- **404 / directory listing:** confirm files are directly inside `htdocs`, and that `index.php` is present.
- **Blank page / HTTP 500:** check PHP syntax and hosting error logs; temporarily enable PHP error logging only while debugging, then disable public error display.
- **Tables missing:** import the SQL file into the correct hosting database.
- **Login fails:** make sure you created an admin on the live database using `setup.php`; local admin accounts are not automatically copied unless you exported the `admins` table too.
- **CSS missing:** upload the complete `assets` folder and preserve folder names.

## Submission documentation
Capture screenshots of:
1. XAMPP with Apache and MySQL running.
2. Local system dashboard.
3. Local phpMyAdmin showing the database and tables.
4. InfinityFree hosting account and website subdomain (hide passwords).
5. Hosting phpMyAdmin showing imported tables.
6. Uploaded project files inside `htdocs`.
7. Live website dashboard in a browser.
8. CRUD test showing a sample student record added and updated.

Do not include real student personal data in screenshots or a public demo.
