<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$student = ['student_no'=>'','first_name'=>'','last_name'=>'','email'=>'','course'=>'','year_level'=>''];
if ($id) {
    $stmt = db()->prepare("SELECT * FROM students WHERE id = ?"); $stmt->execute([$id]); $student = $stmt->fetch();
    if (!$student) { flash('Student record not found.','error'); redirect('students.php'); }
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($student as $key => $value) $student[$key] = trim($_POST[$key] ?? '');
    $student['year_level'] = (int)$student['year_level'];
    if ($student['student_no']==='' || $student['first_name']==='' || $student['last_name']==='' || $student['course']==='' || $student['year_level']<1 || $student['year_level']>6) {
        $error = 'Complete all required fields. Year level must be between 1 and 6.';
    } elseif ($student['email'] !== '' && !filter_var($student['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } else {
        try {
            if ($id) {
                $stmt = db()->prepare("UPDATE students SET student_no=?, first_name=?, last_name=?, email=?, course=?, year_level=? WHERE id=?");
                $stmt->execute([$student['student_no'],$student['first_name'],$student['last_name'],$student['email'] ?: null,$student['course'],$student['year_level'],$id]);
                flash('Student record updated.');
            } else {
                $stmt = db()->prepare("INSERT INTO students (student_no,first_name,last_name,email,course,year_level) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$student['student_no'],$student['first_name'],$student['last_name'],$student['email'] ?: null,$student['course'],$student['year_level']]);
                flash('Student added successfully.');
            }
            redirect('students.php');
        } catch (PDOException $e) {
            $error = $e->getCode() === '23000' ? 'That student number already exists.' : 'Unable to save the record. Check the database connection.';
        }
    }
}
$pageTitle = ($id ? 'Edit' : 'Add') . ' Student | ' . APP_NAME;
require __DIR__ . '/includes/header.php';
?>
<header class="topbar"><div class="brand">STUDENT<span>HUB</span></div><nav><a href="dashboard.php">Dashboard</a><a href="students.php">Students</a><a href="logout.php">Logout</a></nav></header>
<main class="container"><div class="form-card"><h2><?= $id ? 'Edit student' : 'Add new student' ?></h2><p class="muted">Fields marked * are required.</p>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<div class="form-grid">
<div class="field"><label>Student number *</label><input name="student_no" value="<?= e($student['student_no']) ?>" required maxlength="40"></div>
<div class="field"><label>Email address</label><input type="email" name="email" value="<?= e($student['email']) ?>"></div>
<div class="field"><label>First name *</label><input name="first_name" value="<?= e($student['first_name']) ?>" required></div>
<div class="field"><label>Last name *</label><input name="last_name" value="<?= e($student['last_name']) ?>" required></div>
<div class="field"><label>Course / Program *</label><input name="course" value="<?= e($student['course']) ?>" placeholder="e.g. BS Information Technology" required></div>
<div class="field"><label>Year level *</label><select name="year_level" required><option value="">Select year</option><?php for($y=1;$y<=6;$y++): ?><option value="<?= $y ?>" <?= (int)$student['year_level']===$y?'selected':'' ?>>Year <?= $y ?></option><?php endfor; ?></select></div>
</div><div class="actions"><button class="btn" type="submit">Save record</button><a class="btn secondary" href="students.php">Cancel</a></div></form></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
