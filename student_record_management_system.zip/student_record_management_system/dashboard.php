<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$pdo = db();
$total = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$courses = (int)$pdo->query("SELECT COUNT(DISTINCT course) FROM students")->fetchColumn();
$recent = $pdo->query("SELECT * FROM students ORDER BY id DESC LIMIT 5")->fetchAll();
$pageTitle = 'Dashboard | ' . APP_NAME;
require __DIR__ . '/includes/header.php';
$notice = get_flash();
?>
<header class="topbar"><div class="brand">STUDENT<span>HUB</span></div><nav><a href="dashboard.php">Dashboard</a><a href="students.php">Students</a><a href="logout.php">Logout</a></nav></header>
<main class="container"><div class="welcome"><div><h1>Dashboard</h1><div class="muted">Welcome, <?= e($_SESSION['admin_username']) ?>. Here's your student overview.</div></div><a class="btn" href="student_form.php">＋ Add student</a></div>
<?php if ($notice): ?><div class="alert <?= e($notice['type']) ?>"><?= e($notice['message']) ?></div><?php endif; ?>
<section class="cards"><div class="stat"><small>Total students</small><strong><?= $total ?></strong></div><div class="stat"><small>Courses represented</small><strong><?= $courses ?></strong></div><div class="stat"><small>Administrator</small><strong style="font-size:21px"><?= e($_SESSION['admin_username']) ?></strong></div></section>
<section class="panel"><div class="panel-head"><h2>Recently added students</h2><a class="btn secondary" href="students.php">View all</a></div>
<?php if (!$recent): ?><div class="empty">No student records yet. Add your first student to get started.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>Student No.</th><th>Name</th><th>Course</th><th>Year</th></tr></thead><tbody><?php foreach ($recent as $s): ?><tr><td><?= e($s['student_no']) ?></td><td><?= e($s['last_name'] . ', ' . $s['first_name']) ?></td><td><?= e($s['course']) ?></td><td><?= e($s['year_level']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<div class="footer">Student Record Management System · Academic Records</div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
