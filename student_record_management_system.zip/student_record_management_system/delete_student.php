<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('students.php');
verify_csrf();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if ($id) {
    $stmt = db()->prepare("DELETE FROM students WHERE id = ?");
    $stmt->execute([$id]);
    flash('Student record deleted.');
} else flash('Invalid student record.','error');
redirect('students.php');
