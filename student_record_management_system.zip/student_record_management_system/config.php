<?php
// Local XAMPP defaults. Replace these values with your hosting database details before deployment.
define('DB_HOST', 'localhost');
define('DB_NAME', 'student_records');
define('DB_USER', 'root');
define('DB_PASS', '');

define('APP_NAME', 'Student Record Management System');

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
