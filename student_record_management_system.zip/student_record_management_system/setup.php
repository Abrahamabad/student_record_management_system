<?php
require_once __DIR__ . '/config.php';
$message = '';
$error = '';
try {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(80) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS students (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      student_no VARCHAR(40) NOT NULL UNIQUE,
      first_name VARCHAR(80) NOT NULL,
      last_name VARCHAR(80) NOT NULL,
      email VARCHAR(150) DEFAULT NULL,
      course VARCHAR(120) NOT NULL,
      year_level TINYINT UNSIGNED NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $count = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        if ($count > 0) $error = 'An admin account already exists. Delete setup.php and sign in.';
        elseif (strlen($username) < 4 || strlen($password) < 8) $error = 'Use a username with at least 4 characters and a password with at least 8 characters.';
        else {
            $stmt = $pdo->prepare("INSERT INTO admins (username,password) VALUES (?,?)");
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            $message = 'Setup complete. Delete setup.php from your hosting account, then open login.php.';
        }
    }
} catch (Throwable $e) {
    $error = 'Database connection/setup failed. Check config.php and make sure the database exists. Details: ' . $e->getMessage();
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Install Student Records</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login-page"><main class="login-card"><div class="login-mark">🎓</div><h1>System setup</h1><p class="muted">Create the database tables and first administrator account.</p>
<?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($message): ?><div class="alert success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if (!$message && $count === 0): ?><form method="post"><div class="field"><label>Admin username</label><input name="username" minlength="4" required></div><div class="field"><label>Admin password</label><input type="password" name="password" minlength="8" required></div><button class="btn" type="submit" style="width:100%">Install system</button></form><?php elseif ($count > 0): ?><p>An administrator already exists. Remove setup.php and continue to <a href="login.php">login</a>.</p><?php endif; ?>
</main></body></html>
