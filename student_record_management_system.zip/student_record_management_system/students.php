<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = db()->prepare("SELECT * FROM students WHERE student_no LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR course LIKE ? ORDER BY last_name, first_name");
    $like = '%' . $search . '%'; $stmt->execute([$like,$like,$like,$like]); $students = $stmt->fetchAll();
} else $students = db()->query("SELECT * FROM students ORDER BY last_name, first_name")->fetchAll();
$pageTitle = 'Students | ' . APP_NAME;
require __DIR__ . '/includes/header.php'; $notice = get_flash();
?>
<header class="topbar"><div class="brand">STUDENT<span>HUB</span></div><nav><a href="dashboard.php">Dashboard</a><a href="students.php">Students</a><a href="logout.php">Logout</a></nav></header>
<main class="container"><div class="welcome"><div><h1>Student records</h1><div class="muted">Add, search, update, and manage student information.</div></div><a class="btn" href="student_form.php">＋ Add student</a></div>
<?php if ($notice): ?><div class="alert <?= e($notice['type']) ?>"><?= e($notice['message']) ?></div><?php endif; ?>
<section class="panel"><div class="panel-head"><h2>All students (<?= count($students) ?>)</h2><form class="search" method="get"><input name="q" placeholder="Search name, ID, course..." value="<?= e($search) ?>"><button class="btn secondary">Search</button><?php if ($search !== ''): ?><a class="btn dark" href="students.php">Clear</a><?php endif; ?></form></div>
<?php if (!$students): ?><div class="empty">No matching student records found.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>Student No.</th><th>Full name</th><th>Email</th><th>Course</th><th>Year</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($students as $s): ?><tr><td><?= e($s['student_no']) ?></td><td><?= e($s['last_name'] . ', ' . $s['first_name']) ?></td><td><?= e($s['email']) ?></td><td><?= e($s['course']) ?></td><td><?= e($s['year_level']) ?></td><td><div class="actions"><a class="btn secondary" href="student_form.php?id=<?= (int)$s['id'] ?>">Edit</a><form method="post" action="delete_student.php" onsubmit="return confirm('Delete this student record?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn danger" type="submit">Delete</button></form></div></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section><div class="footer">Keep student information accurate and up to date.</div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
